# Experimental modified Ruffle build

Base: https://github.com/ruffle-rs/ruffle/tree/89a7049965f3090e706265670df309a5128233ac

This is not an official unmodified Ruffle binary. The supplied patch modifies queued-goto scheduling in `core/src/display_object/movie_clip.rs`. See the exact patch and provenance hashes. No other tracked upstream source was changed. Ruffle's existing copyrights, licenses, and dependency notices are retained. This candidate is not promoted into the application or approved by upstream.
